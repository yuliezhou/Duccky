<template>
<div class="all_wrap" @click="test">

    <div v-if="show" class="shade"></div>
    <div class="toast" v-if="show">
        <h2 class="title">提示</h2>
        <p class='content'>{{content}}</p>
        <div ref="sure" class="btn_wrap" @click.stop="sure">
            确认
        </div>
    </div>

</div>    
</template>

<script>
export default{
    data(){
        return {
            show:false,
            content:''
        }
    },
    methods:{
         test(){
            this.showToast('1234564897984')
            .then(()=>{
                console.log('55555555')
            })
        },

        //点击确认
        sure(){
            this.show=false
        },
        //显示弹窗
        showToast(content,callback){
            var content=content;
            this.show=true;
            this.content = content;
        //     return new Promise((resolve,reject)=>{
        //   //     this.$refs.addEventListener("click",function(){  
        //             if(this.show==false){
        //                 resolve()
        //             }
        //    //     })
        //     })
        }
    }

}

</script>

<style scoped>
.all_wrap{
    width: 100%;
    height: 100vh;
}
.shade{
    width: 100%;
    height: 100%;
    position: fixed;
    top: 0;
    left: 0;
    background: rgba(0, 0, 0, 0.6);
    z-index: 200;
}
.toast{
    width: 74%;
    height: 24vh;
    position: fixed;
    top: 30%;
    left: 50%;
    margin-left: -37%;
    background: white;
    z-index: 300;
    border-radius: 0.6rem
}
.title{
    text-align: center;
    font-size: 1.4rem;
    margin-top: 0.9rem;
}
.content{
    margin-top: 1.1rem;
    padding: 0 2rem;
    font-size: 1.2rem;
    text-align: center;
    line-height: 1.8rem
}
.btn_wrap{
    position: absolute;
    bottom: 0;
    left: 0;
    width: 100%;
    height: 25%;
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 1.15rem;
    color:deepskyblue;
    border-top: 1px solid gainsboro;
}
</style>
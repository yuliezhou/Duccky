
$("#header li a").click(function(){
    return true;
})

// $(window).scroll(function() {
//         var scrollH = $(window).scrollTop();
//         if (scrollH > 0) {
//             $("#header").addClass('back_header');
//             $('.son-menu.dropdown-menu a').addClass('white_a');
//             $('.son-menu.dropdown-menu').addClass('men_back');
//         } else {
//             $("#header").removeClass('back_header');
//             $('.son-menu.dropdown-menu').removeClass('men_back');
//             $('.son-menu.dropdown-menu a').removeClass('white_a');
//         }
//         // 判断滚动的距离。
//         // banner 的高度
//        var bannerH = $('.banner1').height();
//        if(scrollH >= bannerH/2){
//            // 动画效果-公司简介
//            $('.tran_box3').addClass('animated fadeInUp');
//            $('.tran_box4').addClass('animated fadeInRight');
//             // 动画效果-加入我们
//             $('.join_tran1').addClass('animated1 fadeInDown');       
//             $('.join_tran2').addClass('animated2 fadeInDown');       
//             $('.join_tran3').addClass('animated3 fadeInDown');       
//             $('.join_tran4').addClass('animated4 fadeInDown');   
//             $('.ditu').addClass('animated4 fadeInDown');   
//        }
        
//     })
//分享
    window._bd_share_config = {
        "common": {
            "bdSnsKey": {},
            "bdText": "",
            "bdMini": "2",
            "bdMiniList": false,
            "bdPic": "",
            "bdStyle": "2",
            "bdSize": "24"
        },
        "share": {}
    };
with(document) 0[(getElementsByTagName('head')[0] || body).appendChild(createElement('script')).src = 'http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion=' + ~ ( - new Date() / 36e5)];
// 首页-end------------------------------
setInterval(function(){
   $('#bdshare_weixin_qrcode_dialog .bd_weixin_popup_foot').html('关注公众微信号');
    $('#bdshare_weixin_qrcode_dialog .bd_weixin_popup_head').children('span').html('');
},10)



 
